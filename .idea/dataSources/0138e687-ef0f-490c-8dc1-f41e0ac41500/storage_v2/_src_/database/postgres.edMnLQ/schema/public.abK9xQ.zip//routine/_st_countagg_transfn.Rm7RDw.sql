create function "_st_countagg_transfn"(agg agg_count, rast raster, nband integer, exclude_nodata_value boolean, sample_percent double precision) returns agg_count
  immutable
  parallel safe
  language plpgsql
as
$$
DECLARE
		rtn_agg agg_count;
	BEGIN
		rtn_agg :=  public.__st_countagg_transfn(
			agg,
			rast,
			nband, exclude_nodata_value,
			sample_percent
		);
		RETURN rtn_agg;
	END;

$$;

alter function "_st_countagg_transfn"(agg_count, raster, integer, boolean, double precision) owner to postgres;

