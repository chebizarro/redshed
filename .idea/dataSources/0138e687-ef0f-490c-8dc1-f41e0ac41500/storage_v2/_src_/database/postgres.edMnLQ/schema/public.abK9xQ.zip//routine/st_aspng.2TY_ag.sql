create function st_aspng(rast raster, nband integer, compression integer) returns bytea
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.st_aspng($1, ARRAY[$2], $3)
$$;

comment on function st_aspng(raster, integer, integer) is 'args: rast, nband, compression - Return the raster tile selected bands as a single portable network graphics (PNG) image (byte array). If 1, 3, or 4 bands in raster and no bands are specified, then all bands are used. If more 2 or more than 4 bands and no bands specified, then only band 1 is used. Bands are mapped to RGB or RGBA space.';

alter function st_aspng(raster, integer, integer) owner to postgres;

